# setup.ps1 - first-time setup for DB Documenter (run once after unzipping)
$root = $PSScriptRoot
Write-Host "Setting up DB Documenter..." -ForegroundColor Cyan
python -m venv "$root\backend\.venv"
if ($LASTEXITCODE -ne 0) { Write-Error "python not found. Install Python 3.10+ from python.org"; exit 1 }
& "$root\backend\.venv\Scripts\pip.exe" install -r "$root\backend\requirements.txt"
Write-Host "Setup complete! Run start.ps1 to launch DB Documenter." -ForegroundColor Green
