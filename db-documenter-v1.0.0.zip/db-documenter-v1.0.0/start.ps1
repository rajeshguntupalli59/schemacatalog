# start.ps1 - launch DB Documenter (run after setup)
$root = $PSScriptRoot
Write-Host "Starting backend..." -ForegroundColor Cyan
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$root\backend'; .venv\Scripts\uvicorn.exe main:app --port 8001"
Start-Sleep 2
Write-Host "Opening DB Documenter..." -ForegroundColor Green
Start-Process "http://localhost:8001"
